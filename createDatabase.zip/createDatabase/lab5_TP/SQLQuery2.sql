use testdatabas1 
create table Speciality
(id int Primary Key Identity,
Name nvarchar(20) not null, 
ProhBall int,
submission_of_doc nvarchar(30),
Foreign Key (id) references Faculty(code)
)