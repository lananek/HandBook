use testdatabas1 
create table Department
(id int Primary Key Identity,
Name nvarchar(20) not null, 
DirectorName nvarchar(50) not null,
DirectorDegree nvarchar(20),
NumOfDiscipline int,
Adress nvarchar(30),
Foreign Key (id) references Speciality(id)
)