use testdatabas1 
create table Faculty
(code int Primary Key Identity,
Name nvarchar(20) not null, 
adress nvarchar(40),
FondingDate Date,
Website varchar(30),
Telephone int,
StudingForm nvarchar(15)
)